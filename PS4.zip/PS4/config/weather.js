/*
Configuration information for Open Weather API. Meant for .gitignore
 */

const Weather = {
    APP_ID: '76dfd6e321f189bb2766ac25a3c1db77',
    URL: 'http://api.openweathermap.org/data/2.5/weather?q='

};

module.exports = Weather;